import { useState, useEffect, useCallback } from 'react';

const QUEUE_KEY = 'flipscout_offline_queue';
const SETTINGS_KEY = 'flipscout_settings';

export function useOfflineQueue() {
  const [queue, setQueue] = useState<unknown[]>(() => {
    try { return JSON.parse(localStorage.getItem(QUEUE_KEY) || '[]'); } catch { return []; }
  });
  const [isOnline, setIsOnline] = useState(navigator.onLine);

  useEffect(() => {
    const on = () => setIsOnline(true);
    const off = () => setIsOnline(false);
    window.addEventListener('online', on);
    window.addEventListener('offline', off);
    return () => { window.removeEventListener('online', on); window.removeEventListener('offline', off); };
  }, []);

  const enqueue = useCallback((item: unknown) => {
    setQueue(prev => {
      const next = [...prev, item];
      localStorage.setItem(QUEUE_KEY, JSON.stringify(next));
      return next;
    });
  }, []);

  const flush = useCallback(async (syncFn: (item: unknown) => Promise<void>) => {
    if (!isOnline || queue.length === 0) return;
    const remaining: unknown[] = [];
    for (const item of queue) {
      try { await syncFn(item); } catch { remaining.push(item); }
    }
    setQueue(remaining);
    localStorage.setItem(QUEUE_KEY, JSON.stringify(remaining));
  }, [isOnline, queue]);

  const clearQueue = useCallback(() => {
    setQueue([]);
    localStorage.removeItem(QUEUE_KEY);
  }, []);

  return { queue, isOnline, enqueue, flush, clearQueue, queueSize: queue.length };
}

export function loadSettings(): Record<string, unknown> {
  try { return JSON.parse(localStorage.getItem(SETTINGS_KEY) || '{}'); } catch { return {}; }
}

export function saveSettings(s: Record<string, unknown>) {
  localStorage.setItem(SETTINGS_KEY, JSON.stringify(s));
}
