import { useCallback, useRef, useEffect } from 'react';
import type { AppSettings } from '../types';

const CHA_CHING_URL = 'https://cdn.pixabay.com/audio/2022/03/10/audio_c8c8a73467.mp3';

export function useFeedback(settings: AppSettings) {
  const audioRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    const a = new Audio(CHA_CHING_URL);
    a.volume = 0.6;
    a.preload = 'auto';
    audioRef.current = a;
    return () => { a.pause(); };
  }, []);

  const playSuccess = useCallback(() => {
    if (!settings.soundEnabled) return;
    const a = audioRef.current;
    if (a) { a.currentTime = 0; a.play().catch(() => {}); }
  }, [settings.soundEnabled]);

  const vibrateYes = useCallback(() => {
    if (!settings.hapticEnabled || !navigator.vibrate) return;
    navigator.vibrate(300);
  }, [settings.hapticEnabled]);

  const vibrateNo = useCallback(() => {
    if (!settings.hapticEnabled || !navigator.vibrate) return;
    navigator.vibrate([80, 60, 80]);
  }, [settings.hapticEnabled]);

  const triggerGoodBuy = useCallback(() => {
    playSuccess();
    vibrateYes();
  }, [playSuccess, vibrateYes]);

  const triggerBadBuy = useCallback(() => {
    vibrateNo();
  }, [vibrateNo]);

  return { playSuccess, vibrateYes, vibrateNo, triggerGoodBuy, triggerBadBuy };
}
