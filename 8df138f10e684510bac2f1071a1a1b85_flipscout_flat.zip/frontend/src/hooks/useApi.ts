import { useState, useCallback } from 'react';
import type {
  Store, Category, ProfitAnalysis, ProfitSummary, MyFind, Performance,
  ListingDraft, AppSettings, SuccessStory, ChatMessage,
} from '../types';

const API = process.env.REACT_APP_API_URL || 'http://localhost:8000';

async function get<T>(url: string): Promise<T> {
  const r = await fetch(url);
  if (!r.ok) throw new Error(`API ${r.status}`);
  return r.json();
}
async function post<T>(url: string, body: unknown): Promise<T> {
  const r = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
  if (!r.ok) throw new Error(`API ${r.status}`);
  return r.json();
}
async function put<T>(url: string, body: unknown): Promise<T> {
  const r = await fetch(url, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
  if (!r.ok) throw new Error(`API ${r.status}`);
  return r.json();
}
async function del<T>(url: string): Promise<T> {
  const r = await fetch(url, { method: 'DELETE' });
  if (!r.ok) throw new Error(`API ${r.status}`);
  return r.json();
}

export function useApi() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const wrap = useCallback(async <T>(fn: () => Promise<T>): Promise<T | null> => {
    setLoading(true); setError(null);
    try { const d = await fn(); return d; }
    catch (e: any) { setError(e.message); return null; }
    finally { setLoading(false); }
  }, []);

  const fetchStores = useCallback((zip: string, radius: number) =>
    wrap(() => get<{ stores: Store[] }>(`${API}/api/stores?zip_code=${zip}&radius=${radius}`)), [wrap]);

  const fetchCategories = useCallback(() =>
    wrap(() => get<{ categories: Category[] }>(`${API}/api/categories`)), [wrap]);

  const fetchProfitAnalysis = useCallback((zip: string, radius: number, catId: string, settings: AppSettings) =>
    wrap(() => get<{ analyses: ProfitAnalysis[] } & ProfitSummary>(
      `${API}/api/profit-analysis?zip_code=${zip}&radius=${radius}&category_id=${catId}&target_roi=${settings.targetROI}&store_discount=${settings.storeDiscount}`
    )), [wrap]);

  const fetchLeads = useCallback((zip: string, settings: AppSettings, count = 12) => {
    const cats = settings.enabledCategories.join(',');
    return wrap(() => get<{ leads: ProfitAnalysis[]; totalLeads: number; undisputed: number; strong: number }>(
      `${API}/api/leads?zip_code=${zip}&target_roi=${settings.targetROI}&store_discount=${settings.storeDiscount}&count=${count}&categories=${cats}`
    ));
  }, [wrap]);

  const fetchFinds = useCallback((status = '') =>
    wrap(() => get<{ finds: MyFind[]; total: number }>(`${API}/api/finds?status=${status}`)), [wrap]);

  const saveFind = useCallback((data: Record<string, unknown>) =>
    wrap(() => post<{ id: number }>(`${API}/api/finds`, data)), [wrap]);

  const markSold = useCallback((id: number, soldPrice: number, soldPlatform: string) =>
    wrap(() => put<{ status: string }>(`${API}/api/finds/${id}/sold`, { sold_price: soldPrice, sold_platform: soldPlatform })), [wrap]);

  const deleteFind = useCallback((id: number) =>
    wrap(() => del<{ deleted: boolean }>(`${API}/api/finds/${id}`)), [wrap]);

  const fetchPerformance = useCallback(() =>
    wrap(() => get<Performance>(`${API}/api/performance`)), [wrap]);

  const fetchListingDraft = useCallback((name: string, cat: string, buy: number, sell: number) =>
    wrap(() => get<ListingDraft>(`${API}/api/listing-draft?product_name=${encodeURIComponent(name)}&category=${encodeURIComponent(cat)}&buy_price=${buy}&sell_price=${sell}`)), [wrap]);

  const exportTaxCsv = useCallback(() => {
    window.open(`${API}/api/export/tax-csv`, '_blank');
  }, []);

  const fetchViral = useCallback((zip: string, settings: AppSettings, count = 5) =>
    wrap(() => get<{ items: ProfitAnalysis[]; totalViral: number }>(
      `\${API}/api/viral?zip_code=\${zip}&target_roi=\${settings.targetROI}&store_discount=\${settings.storeDiscount}&count=\${count}`
    )), [wrap]);

  const fetchStories = useCallback((limit = 50) =>
    wrap(() => get<{ stories: SuccessStory[]; total: number; totalCommunityProfit: number }>(`${API}/api/stories?limit=${limit}`)), [wrap]);

  const postStory = useCallback((data: Record<string, unknown>) =>
    wrap(() => post<{ id: number; status: string }>(`${API}/api/stories`, data)), [wrap]);

  const fetchChatHistory = useCallback((limit = 50) =>
    wrap(() => get<{ messages: ChatMessage[]; total: number }>(`${API}/api/chat/history?limit=${limit}`)), [wrap]);

  const sendChatMessage = useCallback((data: Record<string, unknown>) =>
    wrap(() => post<ChatMessage>(`${API}/api/chat/send`, data)), [wrap]);

  return {
    loading, error,
    fetchStores, fetchCategories, fetchProfitAnalysis, fetchLeads,
    fetchFinds, saveFind, markSold, deleteFind,
    fetchPerformance, fetchListingDraft, exportTaxCsv,
    fetchViral, fetchStories, postStory, fetchChatHistory, sendChatMessage,
  };
}
