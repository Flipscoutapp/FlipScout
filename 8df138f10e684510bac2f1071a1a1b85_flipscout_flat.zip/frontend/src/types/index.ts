export interface Store {
  storeId: number; name: string; longName?: string; city: string; region: string;
  address: string; phone: string; distance: number; storeType: string; lat?: number; lng?: number;
}
export interface Category { id: string; name: string; }
export interface ShippingRate { carrier: string; service: string; cost: number; }
export interface IPRisk { isGated: boolean; brand: string | null; warning: string | null; }
export interface Hazmat { isHazmat: boolean; reasons: string[]; warning: string | null; }
export interface MarketTrend {
  sellersNow: number; sellers7dAgo: number; sellerDeltaPct: number;
  priceCrashRisk: boolean; trendLabel: string;
}
export interface AmazonListing {
  amazonIsSeller: boolean; buyBoxOwnerType: string; buyBoxPrice: number | null;
  fbaSellerCount: number; fbmSellerCount: number; totalSellerCount: number;
}
export interface DealScore { score: number; label: string; color: string; }
export interface FBMAnalysis {
  label: string; referralFee: number; referralFeeRate: number; shippingCost: number;
  shippingCarrier: string; shippingService: string; totalFees: number;
  netRevenue: number; profit: number; roi: number; goodBuy: boolean;
}
export interface FBAAnalysis {
  label: string; referralFee: number; referralFeeRate: number;
  fulfillmentFee: number; storageFee: number; inboundShipping: number;
  inboundShippingRate: number; totalFees: number; netRevenue: number;
  profit: number; roi: number; goodBuy: boolean;
}
export interface ViralData {
  isViral: boolean; velocitySpike: boolean; velocityMultiplier: number;
  historicalAvgSales: number; currentVelocity: number;
  hasSocialSignal: boolean; socialPlatforms: string[]; socialKeywords: string[];
  lowStock: boolean; stockEstimate: number; viralLabel: string | null;
}
export interface ProfitAnalysis {
  sku: number; productName: string; aisle: string | null;
  storeBuyPrice: number; storeDiscount: { pct: number; amount: number; adjustedPrice: number };
  salesTax: number; salesTaxRate: number; salesTaxState: string; cogs: number;
  amazonSellPrice: number; weight: number;
  scoutOpinion: string;
  ipRisk: IPRisk; hazmat: Hazmat; viral: ViralData; amazonListing: AmazonListing; marketTrend: MarketTrend;
  shipping: { usps: ShippingRate; fedex: ShippingRate; ups: ShippingRate; cheapest: ShippingRate };
  fbm: FBMAnalysis; fba: FBAAnalysis;
  recommendation: {
    bestMethod: string; bestProfit: number; bestROI: number; goodBuy: boolean;
    rejectionReasons: string[]; primaryRejectionReason: string | null; demandScore: number; estimatedMonthlySales: number;
    positiveVelocity: boolean; competitorCount: number; targetROI: number;
  };
  dealScore?: DealScore; clearancePct?: number; categoryName?: string;
}
export interface ProfitSummary {
  totalAnalyzed: number; goodBuys: number; gatedCount: number; crashRiskCount: number;
  hazmatCount: number; amazonSellerCount: number; salesTaxRate: number; salesTaxState: string;
  targetROI: number; storeDiscount: number;
}
export interface MyFind {
  id: number; sku: number; product_name: string; category_id: string; aisle: string;
  store_buy_price: number; cogs: number; amazon_sell_price: number; best_roi: number;
  best_method: string; good_buy: boolean; zip_code: string; store_id: number;
  status: string; sold_price: number | null; sold_platform: string | null;
  sold_at: number | null; scanned_at: number; notes: string;
  scan_lat: number; scan_lng: number; analysis_json: string;
}
export interface Performance {
  totalFinds: number; scoutedCount: number; soldCount: number;
  totalProfit: number; totalRevenue: number; totalCOGS: number;
  avgROI: number; avgFlipTimeHours: number;
  byPlatform: Record<string, { count: number; revenue: number; profit: number }>;
  recentSales: MyFind[];
}
export interface ListingDraft { title: string; description: string; suggestedPrice: number; category: string; source: string; }
export interface AppSettings {
  targetROI: number; storeDiscount: number; soundEnabled: boolean; hapticEnabled: boolean;
  enabledCategories: string[];
  viralAlertsEnabled: boolean;
}
export interface SuccessStory {
  id: number; user_handle: string; product_name: string; profit_amount: number;
  store_name: string; sold_platform: string; category: string; emoji: string; posted_at: number;
}
export interface ChatMessage {
  id: number; user_handle: string; message: string; msg_type: string;
  product_data: string; posted_at: number;
}
export type TabId = 'home' | 'leads' | 'finds' | 'analytics' | 'community' | 'settings';
