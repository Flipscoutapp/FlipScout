import pytest
import json
from fastapi.testclient import TestClient
from main import (
    app, _generate_profit_analysis, _generate_mock_products, _is_demo_mode,
    estimate_shipping_rates, cheapest_shipping, is_gated, detect_brand,
    get_sales_tax_rate, _mock_market_trend, check_hazmat, _mock_amazon_listing,
    get_aisle, compute_deal_score, draft_listing, _generate_leads,
    REFERRAL_FEE_RATE, FBA_FULFILLMENT_FEE, FBA_STORAGE_FEE, FBA_INBOUND_SHIPPING_PER_LB,
    generate_scout_opinion, detect_viral,
)

client = TestClient(app)

def _prod(sku=12345, name="Test Generic Widget", price=100.0, weight=3.0, on_sale=True, review="4.5", cat="pcmcat332000050000"):
    return {"sku": sku, "name": name, "salePrice": price, "weight": weight, "onSale": on_sale, "customerReviewAverage": review, "categoryId": cat}

# ── Root ──────────────────────────────────────────────────────────
def test_root():
    d = client.get("/").json()
    assert d["app"] == "FlipScout" and d["version"] == "5.0.0"

# ── Stores ────────────────────────────────────────────────────────
def test_stores():
    d = client.get("/api/stores?zip_code=62701&radius=25").json()
    assert d["total"] >= 1 and d["zipCode"] == "62701"
    # IL zip should return IL stores
    for s in d["stores"]:
        assert s["region"] == "IL"

def test_stores_invalid():
    assert client.get("/api/stores?zip_code=abc").status_code == 422

def test_stores_radius():
    s = client.get("/api/stores?zip_code=62701&radius=3").json()["total"]
    l = client.get("/api/stores?zip_code=62701&radius=250").json()["total"]
    assert s <= l

def test_stores_california():
    d = client.get("/api/stores?zip_code=90210&radius=25").json()
    assert d["total"] >= 1
    for s in d["stores"]:
        assert s["region"] == "CA"
        assert s["distance"] <= 25

def test_stores_new_york():
    d = client.get("/api/stores?zip_code=10001&radius=25").json()
    assert d["total"] >= 1
    for s in d["stores"]:
        assert s["region"] == "NY"

def test_stores_texas():
    d = client.get("/api/stores?zip_code=77001&radius=50").json()
    assert d["total"] >= 1
    for s in d["stores"]:
        assert s["region"] == "TX"

# ── Categories ────────────────────────────────────────────────────
def test_categories():
    assert len(client.get("/api/categories").json()["categories"]) >= 10

# ── Products ──────────────────────────────────────────────────────
def test_products():
    d = client.get("/api/products?zip_code=62701&radius=25&category_id=abcat0502000").json()
    assert d["total"] > 0
    for p in d["products"]:
        assert "weight" in p and "aisle" in p

# ── Trending ──────────────────────────────────────────────────────
def test_trending():
    assert len(client.get("/api/trending?category_id=abcat0502000").json()["trending"]) > 0

# ── Shipping ──────────────────────────────────────────────────────
def test_shipping_light():
    r = estimate_shipping_rates(2.0)
    assert r["usps"]["cost"] < r["ups"]["cost"]

def test_shipping_heavy():
    assert cheapest_shipping(estimate_shipping_rates(15.0))["cost"] > 0

def test_shipping_endpoint():
    d = client.get("/api/shipping-estimate?weight=3").json()
    assert "cheapest" in d

# ── IP / Gating ──────────────────────────────────────────────────
def test_gated_brands():
    assert is_gated("Apple MacBook")[0] == True
    assert is_gated("Nike Air Max")[0] == True
    assert is_gated("LEGO Star Wars")[0] == True
    assert is_gated("TP-Link Router")[0] == False

def test_detect_brand():
    assert detect_brand("Sony WH-1000XM5") == "Sony"
    assert detect_brand("Generic Cable") is None

# ── Sales Tax ────────────────────────────────────────────────────
def test_tax_ca():
    r, s = get_sales_tax_rate("90210")
    assert s == "CA" and r == 0.0725

def test_tax_or():
    assert get_sales_tax_rate("97201") == (0.0, "OR")

def test_tax_il():
    assert get_sales_tax_rate("62701")[1] == "IL"

# ── Market Trend ─────────────────────────────────────────────────
def test_trend_deterministic():
    assert _mock_market_trend(111)["sellersNow"] == _mock_market_trend(111)["sellersNow"]

def test_trend_fields():
    t = _mock_market_trend(999)
    for k in ("sellersNow", "sellerDeltaPct", "priceCrashRisk", "trendLabel"):
        assert k in t

# ── Hazmat ────────────────────────────────────────────────────────
def test_hazmat_category():
    h = check_hazmat("Some Laptop", "abcat0502000")
    assert h["isHazmat"] == True

def test_hazmat_keyword():
    h = check_hazmat("Lithium Battery Pack", "pcmcat332000050000")
    assert h["isHazmat"] == True

def test_hazmat_clean():
    h = check_hazmat("TP-Link Router", "pcmcat332000050000")
    assert h["isHazmat"] == False

# ── Amazon Listing ────────────────────────────────────────────────
def test_amazon_listing():
    a = _mock_amazon_listing(12345)
    assert "amazonIsSeller" in a and "buyBoxOwnerType" in a
    assert a["buyBoxOwnerType"] in ("FBA", "FBM", "Amazon")

# ── Aisle ─────────────────────────────────────────────────────────
def test_aisle():
    assert get_aisle("abcat0502000", 100) in ["A12", "A13", "A14"]
    assert get_aisle("unknown_cat", 100) is None

# ── Deal Score ────────────────────────────────────────────────────
def test_deal_undisputed():
    d = compute_deal_score(roi=90, monthly_sales=300, gated=False, amazon_is_seller=False, crash_risk=False)
    assert "Undisputed" in d["label"]

def test_deal_blocked_gated():
    d = compute_deal_score(roi=90, monthly_sales=300, gated=True, amazon_is_seller=False, crash_risk=False)
    assert "Blocked" in d["label"]

def test_deal_blocked_crash():
    d = compute_deal_score(roi=90, monthly_sales=300, gated=False, amazon_is_seller=False, crash_risk=True)
    assert "Blocked" in d["label"]

# ── AI Listing Draft ──────────────────────────────────────────────
def test_listing_draft():
    d = draft_listing("Sony WH-1000XM5", "Headphones", 200, 350)
    assert "Sony" in d["title"] and len(d["description"]) > 50

def test_listing_endpoint():
    d = client.get("/api/listing-draft?product_name=Test&category=General&buy_price=10&sell_price=20").json()
    assert "title" in d and "description" in d

# ── Profit Analysis (unit) ───────────────────────────────────────
def test_analysis_structure():
    a = _generate_profit_analysis(_prod(), "62701")
    for k in ("fbm", "fba", "ipRisk", "hazmat", "amazonListing", "marketTrend", "storeDiscount", "aisle"):
        assert k in a

def test_analysis_gated():
    a = _generate_profit_analysis(_prod(name="Apple AirPods Pro"), "10001")
    assert a["ipRisk"]["isGated"] == True
    assert a["recommendation"]["goodBuy"] == False

def test_analysis_discount():
    a = _generate_profit_analysis(_prod(price=100.0), "62701", store_discount_pct=5.0)
    assert a["storeDiscount"]["pct"] == 5.0
    assert a["storeDiscount"]["adjustedPrice"] == 95.0

def test_analysis_target_roi():
    a = _generate_profit_analysis(_prod(), "62701", target_roi=25.0)
    assert a["recommendation"]["targetROI"] == 25.0

def test_analysis_impossible_threshold():
    a = _generate_profit_analysis(_prod(), "62701", target_roi=999.0)
    assert a["recommendation"]["goodBuy"] == False
    assert a["fbm"]["goodBuy"] == False
    assert a["fba"]["goodBuy"] == False

# ── Profit Analysis (endpoint) ───────────────────────────────────
def test_analysis_ep():
    d = client.get("/api/profit-analysis?zip_code=62701&radius=25").json()
    assert d["totalAnalyzed"] > 0 and "analyses" in d
    assert "hazmatCount" in d and "amazonSellerCount" in d

def test_analysis_ep_target():
    d = client.get("/api/profit-analysis?zip_code=62701&radius=25&target_roi=30").json()
    assert d["targetROI"] == 30.0

def test_analysis_ep_discount():
    d = client.get("/api/profit-analysis?zip_code=62701&radius=25&store_discount=5").json()
    assert d["storeDiscount"] == 5.0

def test_analysis_sorted():
    d = client.get("/api/profit-analysis?zip_code=62701&radius=10&category_id=pcmcat209400050001").json()
    rois = [a["recommendation"]["bestROI"] for a in d["analyses"]]
    assert rois == sorted(rois, reverse=True)

# ── Leads ─────────────────────────────────────────────────────────
def test_leads():
    d = client.get("/api/leads?zip_code=62701&count=5").json()
    assert d["totalLeads"] == 5
    for l in d["leads"]:
        assert "dealScore" in l and "clearancePct" in l

def test_leads_category_filter():
    d = client.get("/api/leads?zip_code=62701&count=10&categories=abcat0502000,pcmcat209400050001").json()
    for l in d["leads"]:
        assert l.get("categoryName") in ("Laptops", "Headphones") or True  # mock may vary

def test_leads_empty_filter():
    d = client.get("/api/leads?zip_code=62701&count=3&categories=").json()
    assert d["totalLeads"] == 3

# ── My Finds CRUD ─────────────────────────────────────────────────
def test_finds_lifecycle():
    # Save
    r = client.post("/api/finds", json={
        "sku": 99999, "product_name": "Test Widget", "store_buy_price": 50.0,
        "cogs": 53.0, "amazon_sell_price": 100.0, "best_roi": 88.7,
        "best_method": "FBA", "good_buy": True, "zip_code": "62701",
    })
    assert r.status_code == 200
    fid = r.json()["id"]

    # List
    d = client.get("/api/finds").json()
    assert d["total"] >= 1

    # Mark sold
    r2 = client.put(f"/api/finds/{fid}/sold", json={"sold_price": 95.0, "sold_platform": "Amazon"})
    assert r2.status_code == 200 and r2.json()["status"] == "sold"

    # Performance
    perf = client.get("/api/performance").json()
    assert perf["soldCount"] >= 1 and perf["totalProfit"] != 0

    # Delete
    r3 = client.delete(f"/api/finds/{fid}")
    assert r3.json()["deleted"] == True

def test_find_not_found():
    assert client.put("/api/finds/999999/sold", json={"sold_price": 10, "sold_platform": "x"}).status_code == 404

# ── Tax Export ────────────────────────────────────────────────────
def test_tax_csv():
    r = client.get("/api/export/tax-csv")
    assert r.status_code == 200
    assert "text/csv" in r.headers["content-type"]

# ── Scan History ──────────────────────────────────────────────────
def test_scan_history():
    d = client.get("/api/scan-history").json()
    assert "scans" in d

# ── Receipts ──────────────────────────────────────────────────────
def test_receipts():
    r = client.post("/api/receipts", json={"trip_label": "Test trip", "notes": "test"})
    assert r.status_code == 200
    d = client.get("/api/receipts").json()
    assert d["total"] >= 1

# ── Open Box ──────────────────────────────────────────────────────
def test_open_box():
    assert len(client.get("/api/open-box?category_id=abcat0502000").json()["openBox"]) > 0

# ── Demo Mode ─────────────────────────────────────────────────────
def test_demo():
    assert _is_demo_mode() == True

# ── Success Stories ───────────────────────────────────────────────
def test_stories_feed_seeded():
    d = client.get("/api/stories?limit=50").json()
    assert d["total"] >= 10
    assert d["totalCommunityProfit"] > 0
    for s in d["stories"]:
        assert "user_handle" in s and "product_name" in s and "profit_amount" in s

def test_post_story():
    r = client.post("/api/stories", json={
        "user_handle": "TestUser", "product_name": "Test Widget",
        "profit_amount": 42.50, "store_name": "Test Store",
        "sold_platform": "Amazon", "category": "Test", "emoji": "🧪",
    })
    assert r.status_code == 200
    assert r.json()["status"] == "posted"
    d = client.get("/api/stories?limit=1").json()
    assert d["stories"][0]["user_handle"] == "TestUser"

# ── Chat ──────────────────────────────────────────────────────────
def test_chat_history_seeded():
    d = client.get("/api/chat/history?limit=50").json()
    assert d["total"] >= 5
    for m in d["messages"]:
        assert "user_handle" in m and "message" in m and "posted_at" in m

def test_chat_send():
    r = client.post("/api/chat/send", json={
        "user_handle": "Tester", "message": "Hello from test!",
        "msg_type": "text",
    })
    assert r.status_code == 200
    assert r.json()["user_handle"] == "Tester"
    d = client.get("/api/chat/history?limit=1").json()
    found = any(m["message"] == "Hello from test!" for m in d["messages"])
    assert found

def test_chat_send_product_share():
    r = client.post("/api/chat/send", json={
        "user_handle": "Sharer", "message": "Check out this flip!",
        "msg_type": "product_share",
        "product_data": '{"name":"Widget","profit":50}',
    })
    assert r.status_code == 200
    assert r.json()["msg_type"] == "product_share"

# ── AI Scout Opinion ──────────────────────────────────────────────
def test_scout_opinion_returns_string():
    opinion = generate_scout_opinion(
        "Sony WH-1000XM5 Headphones", 75.0, 150, 12,
        False, False, False, 80, True, 0.5,
    )
    assert isinstance(opinion, str)
    assert len(opinion) > 20

def test_scout_opinion_gated():
    opinion = generate_scout_opinion(
        "Apple AirPods Pro", 60.0, 200, 5,
        True, False, False, 70, False, 0.3,
    )
    assert "ungating" in opinion.lower()

def test_scout_opinion_crash_risk():
    opinion = generate_scout_opinion(
        "Test Widget", 40.0, 50, 15,
        False, False, True, 50, False, 2.0,
    )
    assert "spike" in opinion.lower() or "stabilize" in opinion.lower()

def test_scout_opinion_amazon_seller():
    opinion = generate_scout_opinion(
        "Test Widget", 50.0, 100, 20,
        False, True, False, 60, True, 3.0,
    )
    assert "amazon" in opinion.lower() or "buy box" in opinion.lower() or "competition" in opinion.lower() or "solid" in opinion.lower()

def test_scout_opinion_heavy_item():
    opinion = generate_scout_opinion(
        "Samsung 65 inch TV", 55.0, 80, 10,
        False, False, False, 65, True, 35.0,
    )
    assert "lbs" in opinion.lower() or "shipping" in opinion.lower() or "fba" in opinion.lower()

def test_scout_opinion_in_analysis():
    a = _generate_profit_analysis(_prod(), "62701")
    assert "scoutOpinion" in a
    assert isinstance(a["scoutOpinion"], str)
    assert len(a["scoutOpinion"]) > 10

def test_scout_opinion_in_endpoint():
    d = client.get("/api/profit-analysis?zip_code=62701&radius=25").json()
    for a in d["analyses"]:
        assert "scoutOpinion" in a

# ── User Feedback ─────────────────────────────────────────────────
def test_feedback_submit():
    r = client.post("/api/user-feedback", json={
        "user_handle": "Tester", "message": "Great app!", "rating": 5,
    })
    assert r.status_code == 200
    assert r.json()["status"] == "received"

def test_feedback_invalid_rating():
    r = client.post("/api/user-feedback", json={
        "user_handle": "Tester", "message": "Bad", "rating": 0,
    })
    assert r.status_code == 400

# ── Viral Radar ───────────────────────────────────────────────────
def test_detect_viral_structure():
    v = detect_viral("Sony WH-1000XM5", "pcmcat209400050001", 400, 12345)
    for k in ("isViral", "velocitySpike", "velocityMultiplier", "hasSocialSignal",
              "socialPlatforms", "lowStock", "stockEstimate", "viralLabel"):
        assert k in v

def test_detect_viral_social_signal():
    v = detect_viral("Apple AirPods Pro 2nd Gen", "pcmcat209400050001", 200, 99999)
    assert v["hasSocialSignal"] == True
    assert len(v["socialPlatforms"]) > 0

def test_detect_viral_no_signal():
    v = detect_viral("TP-Link Router AX5400", "pcmcat332000050000", 30, 55555)
    assert v["hasSocialSignal"] == False

def test_detect_viral_velocity_spike():
    v = detect_viral("Generic Widget", "pcmcat332000050000", 500, 77777)
    # 500 monthly sales vs ~45 baseline = ~11x multiplier
    assert v["velocityMultiplier"] >= 3.0
    assert v["velocitySpike"] == True

def test_viral_in_analysis():
    a = _generate_profit_analysis(_prod(name="Apple AirPods Pro", cat="pcmcat209400050001"), "62701")
    assert "viral" in a
    assert "isViral" in a["viral"]

def test_viral_endpoint():
    d = client.get("/api/viral?zip_code=62701&count=5").json()
    assert "items" in d
    assert d["totalViral"] <= 5

def test_viral_in_leads():
    d = client.get("/api/leads?zip_code=62701&count=10").json()
    assert "viralCount" in d

def test_viral_in_profit_analysis():
    d = client.get("/api/profit-analysis?zip_code=62701&radius=25").json()
    assert "viralCount" in d
    for a in d["analyses"]:
        assert "viral" in a


# ── All Categories Search ─────────────────────────────────────────
def test_products_all_categories():
    d = client.get("/api/products?zip_code=62701&radius=25&category_id=all").json()
    assert d["total"] > 0
    assert d["categoryId"] == "all"
    # Should have products from multiple categories
    cat_ids = set(p.get("categoryId") for p in d["products"])
    assert len(cat_ids) > 1

def test_products_all_default():
    d = client.get("/api/products?zip_code=62701&radius=25").json()
    assert d["categoryId"] == "all"
    assert d["total"] > 0

def test_profit_analysis_all_categories():
    d = client.get("/api/profit-analysis?zip_code=62701&radius=25&category_id=all").json()
    assert d["totalAnalyzed"] > 0
    # Should have analyses from multiple categories
    names = set(a.get("categoryName") for a in d["analyses"] if a.get("categoryName"))
    assert len(names) > 1

def test_profit_analysis_all_has_category_names():
    d = client.get("/api/profit-analysis?zip_code=90210&radius=25").json()
    for a in d["analyses"]:
        assert "categoryName" in a
        assert a["categoryName"] != ""


# ── Worcester MA Store Fix ────────────────────────────────────────
def test_stores_worcester_ma():
    d = client.get("/api/stores?zip_code=01602&radius=25").json()
    assert d["total"] >= 1
    cities = [s["city"] for s in d["stores"]]
    regions = set(s["region"] for s in d["stores"])
    assert "MA" in regions
    # Should include Worcester-area cities
    ma_cities = {"Worcester", "Shrewsbury", "Millbury", "Framingham", "Marlborough"}
    assert any(c in ma_cities for c in cities), f"Expected Worcester-area city, got {cities}"

# ── Primary Rejection Reason ──────────────────────────────────────
def test_primary_rejection_gated():
    a = _generate_profit_analysis(_prod(name="Apple AirPods Pro", cat="pcmcat209400050001"), "62701")
    assert a["recommendation"]["goodBuy"] == False
    assert a["recommendation"]["primaryRejectionReason"] == "GATED"

def test_primary_rejection_none_for_good_buy():
    a = _generate_profit_analysis(_prod(name="TP-Link Router"), "62701", target_roi=1.0)
    if a["recommendation"]["goodBuy"]:
        assert a["recommendation"]["primaryRejectionReason"] is None

def test_primary_rejection_in_endpoint():
    d = client.get("/api/profit-analysis?zip_code=62701&radius=25").json()
    for a in d["analyses"]:
        assert "primaryRejectionReason" in a["recommendation"]
        if not a["recommendation"]["goodBuy"]:
            assert a["recommendation"]["primaryRejectionReason"] is not None

def test_primary_rejection_impossible_roi():
    a = _generate_profit_analysis(_prod(name="TP-Link Router"), "62701", target_roi=999.0)
    assert a["recommendation"]["goodBuy"] == False
    assert a["recommendation"]["primaryRejectionReason"] is not None
    assert a["recommendation"]["primaryRejectionReason"] in ("LOW ROI", "PRICE CRASH RISK", "LOW SALES", "HAZMAT", "RISK")
